<?php
include('conexão.php');
if (isset($_POST['nome'])){
	cadCurriculo($_POST['nome']);
}